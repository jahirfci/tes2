import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Home from './pages/Home';
import Projects from './pages/Projects';
import About from './pages/About';
import Testimonial from './pages/Testimonial';
import Pricing from './pages/Pricing';
import Contact from './pages/Contact';
import Service from './pages/Service';

export default function App(){
	
	
	
	return(
		
		<div>
			<BrowserRouter>
				<Routes>
					<Route path='/' element={<Home/>} />
					<Route path='/projects' element={<Projects/>} />
					<Route path='/about' element={<About/>} />
					<Route path='/testimonial' element={<Testimonial/>} />
					<Route path='/pricing' element={<Pricing/>} />
					<Route path='/service' element={<Service/>} />
					<Route path='/contact' element={<Contact/>} />
				</Routes>
			</BrowserRouter>
			
		</div>
	);
}