import {useRef} from 'react';

export default function Stringa(props){
	let firstName = useRef();
	let lastName = useRef();
	
	function change(){
		let fName= firstName.current.value;
		let lName= lastName.current.value;
		alert(fName+' '+lName);
	}
	
	return(
		<div>
			<input ref={firstName}/>
			<input ref={lastName}/>
			<button onClick={change}>Full Name</button>
		</div>
	);
}