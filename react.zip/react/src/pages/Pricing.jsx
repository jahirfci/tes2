import Header from './Header';
import Footer from './Footer';

function Pricing(){
	
	return(
		<div>
			<Header/>
			<h1>Pricing</h1>
			<Footer/>
		</div>
	);
}

export default Pricing;