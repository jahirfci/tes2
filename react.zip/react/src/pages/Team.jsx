import Header from './Header';
import Footer from './Footer';

function Team(){
	
	return(
		<div>
			<Header/>
			<h1>Team</h1>
			<Footer/>
		</div>
	);
}

export default Team;