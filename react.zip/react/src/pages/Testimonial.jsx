import Header from './Header';
import Footer from './Footer';

function Testimonial(){
	
	return(
		<div>
			<Header/>
			<h1>Testimonial</h1>
			<Footer/>
		</div>
	);
}

export default Testimonial;